const getters = {
    direction: state => state.app.direction,
}
export default getters